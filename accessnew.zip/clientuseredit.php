<?php 
  session_start();
  include 'inc/config.php';
  if ($_SESSION['username'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  $client_id = $_GET['client_id'];
  $error = "";
  $message = "";
  if (isset($_POST['submit'])) {
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $client_type = $_POST['client_type'];
    $company_name = $_POST['company_name'];
    $building_name = $_POST['building_name'];
    $company_email = $_POST['company_email'];
    //$password = rand(00000000, 99999999);
    $company_phone_no = $_POST['company_phone_no'];
    $contact_person = $_POST['contact_person'];
    $contact_email = $_POST['contact_email'];
    $contact_mobile = $_POST['contact_mobile'];
    $special_discount = $_POST['special_discount'];
    if ($firstname == "" || $lastname == "" || $client_type == "" || $company_name == "" || $company_email == "" || $company_phone_no == "" || $contact_person == "" || $contact_email == "" || $contact_mobile == "" || $special_discount == "") {
      $error = "All Fields Are Required";
    }else{
      //$sql = "SELECT * FROM clients WHERE ";
      $sql = "UPDATE clients SET CLIENT_TYPE_ID = '$client_type', COMPANY_ID = '$company_name', CLIENT_FIRST_NAME = '$firstname', CLIENT_MID_NAME = '$middlename', CLIENT_LAST_NAME = '$lastname', BUILDING_NAME = '$building_name', COMPANY_EMAIL = '$company_email', COMPANY_PHONE = '$company_phone_no', CONTACT_PERSION_NAME = '$contact_person', CONTACT_PERSION_EMAIL = '$contact_email', CONTACT_PERSION_NUMBER = '$contact_mobile', SPECIAL_DISCOUNT = '$special_discount' WHERE CLIENT_ID = '$client_id'";
      $query = mysqli_query($con, $sql);
      if ($query) {
        $message = "Data Updated...";
      }else{
        $error = "Something Went Wrong !";
      }
    }
  }

  //get client details
  $sql = "SELECT * FROM clients WHERE CLIENT_ID = '$client_id'";
  $query = mysqli_query($con, $sql);
  $row = mysqli_fetch_assoc($query);
  
 ?>
!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>eHover Access-Dashboard</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    
    <script src="assets/js/config.js"></script>
    <script src="https://code.jquery.com/jquery-1.11.3.js"></script>
    
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'inc/sidebar.php' ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <?php include 'inc/header.php' ?>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
            <div class="row" style="margin: 20px">
                <div class="col-xl">
                  <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Update User/Client</h5>
                      <a href="clientuserlist.php"><small class="text-muted float-end">View All</small></a>
                    </div>
                    <?php 
                      if ($error != "") {
                    ?>
                      <div class="alert alert-danger"><strong><?php echo $error; ?></strong></div>
                    <?php
                     }elseif ($message != "") {
                    ?>
                      <div class="alert alert-success"><strong><?php echo $message; ?></strong></div>
                    <?php 
                      }
                    ?>
                    <div class="card-body">
                      <form action="" method="POST">
                        <div class="row">
                          <div class="col-md-4">
                            <div class="mb-3">
                              <label class="form-label" for="basic-default-fullname">First Name</label>
                              <input type="text" class="form-control" name="firstname" id="basic-default-fullname" placeholder="John" value="<?php echo $row['CLIENT_FIRST_NAME'] ?>" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="mb-3">
                              <label class="form-label" for="basic-default-fullname">Middle Name</label>
                              <input type="text" name="middlename" class="form-control" id="basic-default-fullname" placeholder="Doe" value="<?php echo $row['CLIENT_MID_NAME'] ?>" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="mb-3">
                              <label class="form-label" for="basic-default-fullname">Last Name</label>
                              <input type="text" name="lastname" class="form-control" id="basic-default-fullname" placeholder="Doe" value="<?php echo $row['CLIENT_LAST_NAME'] ?>" />
                            </div>
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-company">Client Type</label>
                          <select class="form-control" name="client_type" id="client_type">
                            <option value="">Please Select Client Type</option>
                            <?php
                              $sql = "SELECT * FROM client_type";
                              $query = mysqli_query($con, $sql);
                              while ($getClientType = mysqli_fetch_assoc($query)) {
                               
                            ?>
                            <option value="<?php echo $getClientType['CLIENT_TYPE_ID'] ?>"><?php echo $getClientType['CLIENT_TYPE_NAME']; ?></option>
                            <?php
                          }
                            ?>
                          </select>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="basic-default-company">Company Name</label>
                          <select class="form-control" name="company_name" id="company_name">
                            
                          </select>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Building Name</label>
                          <input type="text" name="building_name" id="numberOfToken" class="form-control" placeholder="Building Name" value="<?php echo $row['BUILDING_NAME'] ?>">
                        </div>
                        <div class="form-group">
                          <div class="mb-3">
                            <label class="form-label" for="basic-default-email">Company Email</label>
                            <div class="input-group input-group-merge">
                              <input
                                type="text"
                                name="company_email"
                                id="basic-default-email"
                                class="form-control"
                                placeholder="john.doe"
                                aria-label="john.doe"
                                aria-describedby="basic-default-email2"
                                value="<?php echo $row['COMPANY_EMAIL'] ?>"
                              />
                              <span class="input-group-text" id="basic-default-email2">@example.com</span>
                            </div>
                            <div class="form-text">You can use letters, numbers & periods</div>
                          </div>
                          <div class="mb-3">
                            <label class="form-label" for="basic-default-phone">Company Phone No</label>
                            <input
                              type="text"
                              value="<?php echo $row['COMPANY_PHONE'] ?>"
                              name="company_phone_no"
                              id="basic-default-phone"
                              class="form-control phone-mask"
                              placeholder="658 799 8941"
                            />
                          </div>
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Special Discount</label>
                          <input type="text" name="special_discount" id="" class="form-control" placeholder="Special Discount" value="<?php echo $row['SPECIAL_DISCOUNT'] ?>">
                        </div>
                        <div class="row">
                          <div class="col-md-9">
                          <div id="req_input" class="datainputs">
                          <input name="contact_person" value="<?php echo $row['CONTACT_PERSION_NAME'] ?>" class="form-control" style="margin: 10px" placeholder="Contact Persion Name" type="text">
                          <input name="contact_email" value="<?php echo $row['CONTACT_PERSION_EMAIL'] ?>" class="form-control" style="margin: 10px" placeholder="Contact Persion Email" type="text">
                          <input name="contact_mobile" value="<?php echo $row['CONTACT_PERSION_NUMBER'] ?>" class="form-control" style="margin: 10px" placeholder="Contact Persion Mobile" type="text">
                        </div>
                        </div>
                        <div class="col-md-3">
                          <a href="#" id="addmore" class="add_input btn btn-primary">Add more</a>
                        </div>
                        </div>
                        <!-- <div class="mb-3">
                          <label class="form-label" for="no-of-token">Special Discount</label>
                          <input type="text" name="" id="discount" class="form-control" placeholder="10%">
                        </div> -->
                        <!-- <div class="mb-3">
                          <label class="form-label" for="basic-default-message">Message</label>
                          <textarea
                            id="basic-default-message"
                            class="form-control"
                            placeholder="Hi, Do you have a moment to talk Joe?"
                          ></textarea>
                        </div> -->
                        <button type="submit" name="submit" class="btn btn-primary">UPDATE</button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            <!-- / Content -->
            <?php include 'inc/footer.php' ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <script type="text/javascript">
      $(document).ready(function() {
  $("#addmore").click(function() {
    $("#req_input").append('<div class="required_inp"><input style="margin: 10px" class="form-control" name="fname" placeholder="Text Field 1" type="text"><input style="margin: 10px" name="lname" class="form-control" placeholder="Text Field 2" type="text"><input style="margin: 10px" name="lname" class="form-control" placeholder="Text Field 3" type="text">' + '<input type="button" class="inputRemove btn btn-danger pull-right" style="margin: 10px" value="Remove"/></div>');
  });
  $('body').on('click','.inputRemove',function() {
    $(this).parent('div.required_inp').remove()
  });
});

//get company name by client type
$(document).ready(function() {
$('#client_type').on('change', function() {
var client_type_id = this.value;
$.ajax({
url: "get_company_name.php",
type: "POST",
data: {
client_type_id: client_type_id
},
cache: false,
success: function(result){
$("#company_name").html(result);

}
});
});
})
    </script>
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>

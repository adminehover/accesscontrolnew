<?php 
  session_start();
  include 'inc/config.php';
  if ($_SESSION['username'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  $package_type_id = $_GET['package_type_id'];
  $sql = "DELETE FROM package_type WHERE PACKAGE_TYPE_ID = '$package_type_id'";
  $query = mysqli_query($con, $sql);
  if ($query) {
    echo "<script>window.location.assign('package_type_list.php');</script";
  }else{
    echo "<script>window.location.assign('package_type_list.php');</script";
  }
?>
<?php 
  session_start();
  include 'inc/config.php';
  if ($_SESSION['username'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  $package_id = $_GET['package_id'];
  $sql = "DELETE FROM package WHERE PACKAGE_ID = '$package_id'";
  $query = mysqli_query($con, $sql);
  if ($query) {
    echo "<script>window.location.assign('package_list.php');</script";
  }else{
    echo "<script>window.location.assign('package_list.php');</script";
  }
?>
<?php 
  session_start();
  include 'inc/config.php';
  if ($_SESSION['username'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  $device_id = $_GET['client_id'];
  $sql = "DELETE FROM device WHERE DEVICE_ID = '$client_id'";
  $query = mysqli_query($con, $sql);
  if ($query) {
    echo "<script>window.location.assign('clientuserlist.php');</script";
  }else{
    echo "<script>window.location.assign('clientuserlist.php');</script";
  }
?>
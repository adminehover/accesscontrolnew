<?php 
  session_start();
  include 'inc/config.php';
  if ($_SESSION['user'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  $package_id =  $_POST['package_id'];
  $package_type_id = $_POST['package_type_id'];
  $device_qty = $_POST['device_qty'];
  $cable_qty = $_POST['cable_qty'];
 
  
  $error = "";
  $message = "";
  //Get Package details
  $getPackage = "SELECT * FROM package WHERE PACKAGE_ID = '$package_id'";
  $queryPackage = mysqli_query($con, $getPackage);
  $rowPackage = mysqli_fetch_assoc($queryPackage);
  // Get Package Type
  $getPackageType = "SELECT * FROM package_type WHERE PACKAGE_TYPE_ID = '$package_type_id'";
  $queryPackageType = mysqli_query($con, $getPackageType);
  $rowPackageType = mysqli_fetch_assoc($queryPackageType);
  // Get Client Details
  $email = $_SESSION['user'];
  $getClient = "SELECT * FROM clients WHERE COMPANY_EMAIL = '$email'";
  $queryClient = mysqli_query($con, $getClient);
  $rowClient = mysqli_fetch_assoc($queryClient);
  // get Price Details 
  $getDevice = "SELECT * FROM prices LIMIT 1";
  $queryDevice = mysqli_query($con, $getDevice);
  $rowPrice = mysqli_fetch_assoc($queryDevice);
  ///get client details

  if (isset($_POST['submit'])) {
    $package_id = $_POST['package_id'];
    $package_type_id = $_POST['package_type_id'];
    $device_qty = $_POST['device_qty'];
    $cable_qty = $_POST['cable_qty'];
    $address1 = $_POST['address1'];
    $address2 = $_POST['address2'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $zip = $_POST['zip'];
    $total_one_time_price = $_POST['total_one_time_price'];
    $total_one_time_discount = $_POST['total_one_time_discount'];
    $one_time_fine_price = $_POST['one_time_fine_price'];
    $package_type_total = $_POST['package_type_total'];
    $package_type_dis = $_POST['package_type_dis'];
    $package_type_final = $_POST['package_type_final'];
    $gst_amount = $_POST['gst_amount'];
    $grand_total = $_POST['grand_total'];
    $client_id = $rowClient['CLIENT_ID'];
    $order_date = date("d/m/Y");
    $sql = "INSERT INTO orders(CLIENT_ID, PACKAGE_ID, PACKAGE_TYPE_ID, DEVICE_QTY, CABLE_QTY, LABOUR_QTY, ADDRESS1, ADDRESS2, STATE, CITY, ZIP, TOTAL_ONE_TIME_PRICE, ONE_TIME_PRICE_DISCOUNT, ONE_TIME_FINAL_PRICE, PACKAGE_TYPE_TOTAL, PACKAGE_TYPE_DISCOUNT, PACKAGE_TYPE_FINAL_PRICE, TOTAL_PRICE, GST,GRAND_TOTAL, ODER_DATE) value('$client_id', '$package_id', '$package_type_id', '$device_qty', '$cable_qty', '$device_qty', '$address1', '$address2', '$state', '$city', '$zip', '$total_one_time_price', '$total_one_time_discount', '$one_time_fine_price', '$package_type_total', '$package_type_dis', '$package_type_final', '$gst_amount', '$grand_total', '$grand_total', '$order_date')";
    $query = mysqli_query($con, $sql);
    if ($query) {
      echo "<script>window.location.assign('thank-you.php');</script>";
    }else{
      $error = "Something went wrong ! Please try again latter...";
    }

  }
  // if ($package_id == "") {
  //   echo "<script>window.location.assign('packages.php');</script>";
  // }
?>
<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />
    <title>eHover Access-Dashboard</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    
    <script src="assets/js/config.js"></script>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'inc/sidebar.php' ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <?php include 'inc/header.php' ?>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="card">
                  <div class="card-header">
                    <h3>Checkout</h3>
                  </div>
                  <div class="card-body">
                    <?php 
                      if ($message != "") {
                    ?>
                      <div class="alert alert-success">
                        <strong><?php echo $message; ?></strong>
                      </div>
                    <?php 
                      }elseif ($error != "") {
                    ?>
                    <div class="alert alert-danger">
                      <strong><?php echo $error; ?></strong>
                    </div>
                    <?php  
                      }
                    ?>
                    <form action="" method="POST">
                      <input type="hidden" name="package_id" value="<?php echo $package_id; ?>">
                      <input type="hidden" name="package_type_id" value="<?php echo $package_type_id; ?>">
                      <input type="hidden" name="device_qty" value="<?php echo $device_qty; ?>">
                      <input type="hidden" name="cable_qty" value="<?php echo $cable_qty; ?>">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label>First Name *</label>
                                <input type="text" name="first_name" class="form-control" value="<?php echo $rowClient['CLIENT_FIRST_NAME']; ?>">
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group">
                                <label>Last Name *</label>
                                <input type="text" name="last_name" class="form-control" value="<?php echo $rowClient['CLIENT_LAST_NAME']; ?>">
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group">
                                <label>Email Id *</label>
                                <input type="text" name="email" class="form-control" value="<?php echo $rowClient['COMPANY_EMAIL']; ?>">
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group">
                                <label>Phone *</label>
                                <input type="text" name="Phone" class="form-control" value="<?php echo $rowClient['COMPANY_PHONE']; ?>">
                              </div>
                            </div>
                            <div class="row">
                              <div class="form-group">
                                <label>Address 1 *</label>
                                <input type="text" name="address1" class="form-control" required>
                              </div>
                            </div>
                            <div class="row">
                              <div class="form-group">
                                <label>Address 2 *</label>
                                <input type="text" name="address2" class="form-control" required>
                              </div>
                            </div>
                            <div class="row">
                              <div class="form-group">
                                <label>State *</label>
                                <input type="text" name="state" class="form-control" required>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col-md-6">
                                <div class="form-group">
                                  <label>City *</label>
                                  <input type="text" name="city" class="form-control" required>
                                </div>
                              </div>
                              <div class="col-md-6">
                                <div class="form-group">
                                  <label>ZIP *</label>
                                  <input type="text" name="zip" class="form-control" required>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="card">
                            <h3 class="card-header">Order Details</h3>
                            <div class="table-responsive text-nowrap">
                              <h4 style="margin-left: 25px">One Time Payment Details </h4>
                              <table class="table">
                                <thead>
                                  <tr>
                                    <th>Iteam</th>
                                    <th>price</th>
                                    <th>qty</th>
                                    <th>Total Price</th>
                                  </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                  <tr>
                                    <td>Device</td>
                                    <td><?php echo $rowPrice['DEVICE_PRICE']; ?></td>
                                    <td><?php echo $device_qty; ?></td>
                                    <td><?php echo $tdp = $rowPrice['DEVICE_PRICE'] * $device_qty; ?></td>
                                  </tr>
                                  <tr>
                                    <td>Labour Cost</td>
                                    <td><?php echo $rowPrice['LABOUR_COST']; ?></td>
                                    <td><?php echo $device_qty; ?></td>
                                    <td><?php echo $tlp = $rowPrice['LABOUR_COST'] * $device_qty; ?></td>
                                  </tr>
                                  
                                  <tr>
                                    <td>Cable</td>
                                    <td><?php echo $rowPrice['CABLE_PRICE']; ?></td>
                                    <td><?php echo $cable_qty; ?></td>
                                    <td><?php echo $tcp = $rowPrice['CABLE_PRICE'] * $cable_qty; ?></td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                            <hr class="solid">
                            <div class="row">
                                <div class="col-md-6">
                                  <p style="text-align: center;">Total Price: </p>
                                </div>
                                <div class="col-md-6">
                                  <p style="text-align: center;"><?php echo $total_price1 = $tdp + $tlp + $tcp; ?></p>
                                  <input type="hidden" name="total_one_time_price" value="<?php echo $total_price1; ?>">
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                  <p style="text-align: center;">Discount: <?php echo $ddis = $rowPackage['DISCOUNT']; ?>%</p>
                                  
                                </div>
                                <div class="col-md-6">
                                  <p style="text-align: center;">-<?php echo $total_ddis = ($total_price1 * $ddis)/ 100; ?></p>
                                </div>
                                <input type="hidden" name="total_one_time_discount" value="<?php echo $total_ddis; ?>">
                            </div>
                            <hr class="solid">
                            <div class="row">
                                <div class="col-md-6">
                                  <p style="text-align: center;">Sub Total: </p>
                                </div>
                                <div class="col-md-6">
                                  <p style="text-align: center;"><?php echo $sub_total = $total_price1 - $total_ddis; ?></p>
                                </div>
                            </div>
                            <input type="hidden" name="one_time_fine_price" value="<?php echo $sub_total; ?>">
                            <hr class="solid">
                            <div class="table-responsive text-nowrap">
                              <h3>Token Details & Price</h3>
                              <table class="table">
                                <tbody class="table-border-bottom-0">
                                  <thead>
                                  <tr>
                                    <th>Iteam</th>
                                    <th>price</th>
                                    <th>qty</th>
                                    <th>Total Price</th>
                                  </tr>
                                </thead>
                                  <tr>
                                    <td>Tokens for <?php echo $rowPackageType['MONTHS']; ?> months</td>
                                    <td><?php echo $rowPrice['TOKEN_PRICE']; ?></td>
                                    <td><?php echo $rowPackage['MAX_NO_OF_TOKEN']; ?></td>
                                    <td><?php echo $ttp = ($rowPrice['TOKEN_PRICE'] * $rowPackage['MAX_NO_OF_TOKEN']) * $rowPackageType['MONTHS']; ?></td>
                                  </tr>
                                  
                                </tbody>
                              </table>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                  <p style="text-align: center;">Total Price: </p>
                                </div>
                                <div class="col-md-6">
                                  <p style="text-align: center;"><?php echo $ttp; ?></p>
                                  <input type="hidden" name="package_type_total" value="<?php echo $ttp; ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                  <p style="text-align: center;">Discount: <?php echo $tdis = $rowPackageType['PACKAGE_TYPE_DISCOUNT']; ?>%</p>
                                </div>
                                <div class="col-md-6">
                                  <p style="text-align: center;">-<?php echo $total_tdis = ($ttp * $tdis)/ 100; ?></p>
                                  <input type="hidden" name="package_type_dis" value="<?php echo $total_tdis; ?>">
                                </div>
                            </div>
                            <hr class="solid">
                            <div class="row">
                                <div class="col-md-6">
                                  <p style="text-align: center;">Sub Total: </p>
                                </div>
                                <div class="col-md-6">
                                  <p style="text-align: center;"><?php echo $sub_total1 = $ttp - $total_tdis; ?></p>
                                  <input type="hidden" name="package_type_final" value="<?php echo $sub_total1; ?>">
                                </div>
                            </div>
                            <hr class="solid">
                            <div class="row">
                                <div class="col-md-6">
                                  <p style="text-align: center;">Total: <?php echo $sub_total; ?> + <?php echo $sub_total1; ?></p>
                                </div>
                                <div class="col-md-6">
                                  <p style="text-align: center;"><?php echo $total = $sub_total + $sub_total1; ?></p>
                                </div>
                                <input type="hidden" name="order_total_price" value="<?php echo $total; ?>">
                            </div>
                            <hr class="solid">
                            <div class="row">
                                <div class="col-md-6">
                                  <p style="text-align: center;">GST 18% </p>
                                </div>
                                <div class="col-md-6">
                                  <p style="text-align: center;">+<?php echo $gst = ($total * 18)/100; ?></p>
                                </div>
                            </div>
                            <input type="hidden" name="gst_amount" value="<?php echo $gst; ?>">
                            <hr class="solid">
                            <div class="row">
                                <div class="col-md-6">
                                  <p style="text-align: center;">Grand Total: </p>
                                </div>
                                <div class="col-md-6">
                                  <p style="text-align: center;"><?php echo $grand_total = $total + $gst; ?></p>
                                </div>
                            </div>
                            <input type="hidden" name="grand_total" value="<?php echo $grand_total ?>">
                            </div>
                          <!--/ Basic Bootstrap Table -->
                        </div>
                      </div>
                      <button type="submit" class="btn btn-success" name="submit">Pay Now</button>
                    </form>
                  </div>
                </div>
              </div>
              </div>
            </div>
            <!-- / Content -->
            <?php include 'inc/footer.php' ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->


    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>

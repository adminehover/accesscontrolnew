<?php
	define('HOST', 'localhost');
	define('USER', 'root');
	define('PASS', '');
	define('DB', 'access');
	$con = mysqli_connect(HOST, USER, PASS, DB);
?>
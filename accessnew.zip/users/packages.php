<?php 
  session_start();
  if ($_SESSION['user'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  include 'inc/config.php';
  $getDevice = "SELECT * FROM prices LIMIT 1";
  $queryDevice = mysqli_query($con, $getDevice);
  $rowPrice = mysqli_fetch_assoc($queryDevice);
?>
<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />
    <title>eHover Access-Dashboard</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>

    
    <script src="assets/js/config.js"></script>
  </head>

  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <?php include 'inc/sidebar.php' ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <?php include 'inc/header.php' ?>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <form action="checkout.php" method="POST">
              <div class="row">
                <?php
                  $sql = "SELECT * FROM package";
                  $query = mysqli_query($con, $sql);
                  while ($row = mysqli_fetch_assoc($query)) {
                ?>
                <div class="col-md-4">
                  <div class="card">
                    <div class="card-body">
                      <div class="card-title">
                        <h3 style="text-align: center;"><?php echo $row['PACKAGE_NAME']; ?></h3> 
                      </div>
                      <hr class="solid">
                          <div class="row">
                            <h6>Token details</h6>
                            <p>Price For 1 token: <br><span style="color: green"><i class="bx bx-rupee"></i><?php echo $rowPrice['TOKEN_PRICE'] ?></span></p>
                            <div class="col-md-6">
                              <p>Min Token</p>
                              <p><?php echo $row['MIN_NO_OF_TOKEN']; ?></p>
                            </div>
                            <div class="col-md-6">
                              <p>Max Token</p>
                              <p><?php echo $row['MAX_NO_OF_TOKEN']; ?></p>
                            </div>
                          </div>
                          <hr class="solid">
                           <div class="row">
                            <h6>Device details</h6>
                            <p>Price For 1 Device: <br><span style="color: green"><i class="bx bx-rupee"></i><?php echo $rowPrice['DEVICE_PRICE'] ?></span></p>
                            <div class="form-group">
                              <label>Device QTY</label><br>
                              <small>How many Device You Need ?</small>
                              <input type="number" name="device_qty" class="form-control" value="1" required>
                            </div>
                          </div>
                          <hr class="solid">
                          <div class="row" style="margin-top: 10px;">
                            <h6>Labour cost details</h6>
                            <p>Price for 1 device installation: <br><span style="color: green"><i class="bx bx-rupee"></i><?php echo $rowPrice['LABOUR_COST'] ?></span></p>
                          </div>
                          <hr class="solid">
                          <div class="row">
                            <h6>Cable details</h6>
                            <p>Price for 1 meter: <br><span style="color: green"><i class="bx bx-rupee"></i><?php echo $rowPrice['CABLE_PRICE'] ?></span></p>
                            <div class="form-group">
                              <label>Cable QTY</label><br>
                              <small>Minimum 30 meter cable ?</small>
                              <input type="number" name="cable_qty" class="form-control" min="30" value="30" required>
                            </div>
                          </div>
                          <hr class="solid">
                          <div class="row" style="margin-top: 10px">
                            <p style="color: green;"><b>Discount:</b> <?php echo $row['DISCOUNT']; ?>%</p>
                            <input type="hidden" name="package_id" id="package_discount" value="<?php echo $row['PACKAGE_ID']; ?>">
                          </div>
                          <hr class="solid">
                          <div class="row">
                            <div class="form-group">
                              <select class="form-control" id="package_type" name="package_type_id" required>
                                <option value="">Select Duration</option>
                                <?php 
                                  $sql = "SELECT * FROM package_type";
                                  $query = mysqli_query($con, $sql);
                                  while ($row = mysqli_fetch_assoc($query)) {
                                   
                                ?>
                                <option value="<?php echo $row['PACKAGE_TYPE_ID']; ?>"><?php echo $row['PACKAGE_TYPE_NAME']; ?> <span class="pull-right">(Discount <?php echo $row['PACKAGE_TYPE_DISCOUNT']; ?>%)</span></option>
                              <?php } ?>
                              </select>

                            </div>
                          </div>
                          
                          <div class="row" style="margin-top: 10px;">
                            <center><button type="submit" class="btn btn-success">BUY NOW</button></center>
                          </div>
                      </form>
                    </div>
                  </div>
                </div>
                <?php } ?>
              </div>
                
              </div>
              
            </div>
            <!-- / Content -->
            <?php include 'inc/footer.php' ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <script type="text/javascript">
      // function myFunction() {
      //   let package_discount = document.getElementById('package_discount').value;
      //   let package_type_discount = document.getElementById('package_type').value;
      //   let total_dis = parseInt(package_discount) + parseInt(package_type_discount);
      //   document.getElementById('total_discount').innerHTML = 'Total Discount '+total_dis;
      // }
    </script>
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>

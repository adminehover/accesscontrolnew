<?php 
  session_start();
  include 'inc/config.php';
  if ($_SESSION['username'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  $emp_id = $_GET['emp_id'];
  $sql = "DELETE FROM employee WHERE EMP_ID = '$emp_id'";
  $query = mysqli_query($con, $sql);
  if ($query) {
    echo "<script>window.location.assign('employee_list.php');</script";
  }else{
    echo "<script>window.location.assign('employee_list.php');</script";
  }
?>
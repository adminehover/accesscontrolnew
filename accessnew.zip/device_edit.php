<?php 
  session_start();
  include 'inc/config.php';
  if ($_SESSION['username'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  $error = "";
  $message = "";
  $device_id = $_GET['device_id'];

  if (isset($_POST['submit'])) {
    $device_name = $_POST['divice_name'];
    // $device_price = $_POST['device_price'];
    // $labour_cost = $_POST['labour_cost'];
    $device_password = $_POST['device_password'];
    if ($device_name == "" || $device_password == "") {
      $error = "All Fields Are Required...";
    }else{
      $sql = "UPDATE device SET DEVICE_NAME = '$device_name', DEVICE_PASSWORD = '$device_password' WHERE DEVICE_ID = '$device_id'";
      $query = mysqli_query($con, $sql);
      if ($query) {
        $message = "Device updated...";
      }else{
        $error = "Something Went Wrong !";
      }
    }
  }
?>
<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />
    <title>eHover Access-Dashboard</title>
    <meta name="description" content="" />
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />
    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>
    <script src="assets/js/config.js"></script>
  </head>
  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
        <?php include 'inc/sidebar.php' ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
          <?php include 'inc/header.php' ?>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
            <div class="row" style="margin: 20px">
                <div class="col-xl">
                  <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Update Device</h5>
                      <a href="device_list.php"><small class="text-muted float-end">View All</small></a>
                    </div>
                    <?php 
                      if ($error != "") {
                    ?>
                      <div class="alert alert-danger"><strong><?php echo $error; ?></strong></div>
                    <?php 
                      }elseif ($message != "") {
                    ?>
                      <div class="alert alert-success"><strong><?php echo $message; ?></strong></div>
                    <?php
                      }
                    ?>
                    <div class="card-body">
                      <form action="" method="POST">
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Device Name</label>
                          <input type="text" name="divice_name" id="discount" class="form-control" placeholder="Device Name">
                        </div>
                        <!-- <div class="mb-3">
                          <label class="form-label" for="no-of-token">BLE Device Price</label>
                          <input type="text" name="device_price" id="discount" class="form-control" placeholder="BLE Device Price" value="5000">
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Labour Cost For 1 Device</label>
                          <input type="text" name="labour_cost" id="" class="form-control" placeholder="Labour Cost" value="2500">
                        </div> -->
                        <!-- <div class="mb-3">
                          <label class="form-label" for="no-of-token">Cable Price Per Meter</label>
                          <input type="text" name="" id="discount" class="form-control" placeholder="Cable Price">
                        </div> -->
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Device Password</label>
                          <input type="text" name="device_password" id="discount" class="form-control" placeholder="123456">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">UPDATE</button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            <!-- / Content -->
            <?php include 'inc/footer.php' ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>

<?php 
  session_start();
  include 'inc/config.php';
  if ($_SESSION['username'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  $error = "";
  $message = "";
  $emp_id = $_GET['emp_id'];
  if (isset($_POST['submit'])) {
    $emp_name = $_POST['emp_name'];
    $emp_email = $_POST['emp_email'];
    $emp_mobile = $_POST['emp_phone'];
    //$emp_password = $_POST['password'];
    $emp_age = $_POST['emp_age'];
    $emp_blood = $_POST['emp_blood'];
    $emp_address = $_POST['emp_address'];
    $emp_designation = $_POST['emp_designation'];
    if ($emp_name == "" || $emp_email == "" || $emp_mobile == "" || $emp_age == "" || $emp_blood == "" || $emp_address == "" || $emp_designation == "") {
      $error = "All Fields Are Required...";
    }else{
      $sql = "UPDATE employee SET EMP_NAME = '$emp_name', EMP_EMAIL = '$emp_email', EMP_MOBILE = '$emp_mobile', EMP_AGE = '$emp_age', EMP_BLOOD = '$emp_blood', EMP_ADDRESS = '$emp_address', EMP_DESIGNATION = '$emp_designation' WHERE EMP_ID = '$emp_id'";
      $query = mysqli_query($con, $sql);
      if ($query) {
        $message = "Employee Updated...";
      }else{
        $error = "Something Went Wrong !";
      }
    }
  }
  $sql = "SELECT * FROM employee WHERE EMP_ID = '$emp_id'";
  $query = mysqli_query($con, $sql);
  $row = mysqli_fetch_assoc($query);
?>
<!DOCTYPE html>
<html
  lang="en"
  class="light-style layout-menu-fixed"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />
    <title>eHover Access-Dashboard</title>
    <meta name="description" content="" />
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon/favicon.ico" />
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />
    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>
    <script src="assets/js/config.js"></script>
  </head>
  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->
        <?php include 'inc/sidebar.php' ?>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->
          <?php include 'inc/header.php' ?>
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->
            <div class="row" style="margin: 20px">
                <div class="col-xl">
                  <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                      <h5 class="mb-0">Update Employee</h5>
                      <a href="employee_list.php"><small class="text-muted float-end">View All</small></a>
                    </div>
                    <?php 
                      if ($error != "") {
                    ?>
                      <div class="alert alert-danger"><strong><?php echo $error; ?></strong></div>
                    <?php 
                      }elseif ($message != "") {
                    ?>
                      <div class="alert alert-success"><strong><?php echo $message; ?></strong></div>
                    <?php
                      }
                    ?>
                    <div class="card-body">
                      <form action="" method="POST">
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Employee Name</label>
                          <input type="text" name="emp_name" id="discount" class="form-control" placeholder="Employee Name" value="<?php echo $row['EMP_NAME']; ?>">
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Email</label>
                          <input type="text" name="emp_email" id="discount" class="form-control" placeholder="Employee Email" value="<?php echo $row['EMP_EMAIL']; ?>">
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Mobile Number</label>
                          <input type="text" name="emp_phone" id="" class="form-control" placeholder="Mobile Number" value="<?php echo $row['EMP_MOBILE']; ?>">
                        </div>
                        <!-- <div class="mb-3">
                          <label class="form-label" for="no-of-token">Password</label>
                          <input type="password" name="password" id="discount" class="form-control" placeholder="Password" >
                        </div> -->
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">AGE</label>
                          <input type="text" name="emp_age" id="discount" class="form-control" placeholder="AGE" value="<?php echo $row['EMP_AGE']; ?>">
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Blood Group</label>
                          <input type="text" name="emp_blood" id="discount" class="form-control" placeholder="Blood Group" value="<?php echo $row['EMP_BLOOD']; ?>">
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Full Address</label>
                          <input type="text" name="emp_address" id="discount" class="form-control" placeholder="Full Address" value="<?php echo $row['EMP_ADDRESS']; ?>">
                        </div>
                        <div class="mb-3">
                          <label class="form-label" for="no-of-token">Designation</label>
                          <input type="text" name="emp_designation" id="discount" class="form-control" placeholder="Designation" value="<?php echo $row['EMP_DESIGNATION']; ?>">
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">UPDATE</button>
                      </form>
                    </div>
                  </div>
                </div>
                
              </div>
            <!-- / Content -->
            <?php include 'inc/footer.php' ?>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>

      <!-- Overlay -->
      <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/libs/jquery/jquery.js"></script>
    <script src="assets/vendor/libs/popper/popper.js"></script>
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="assets/vendor/libs/apex-charts/apexcharts.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="assets/js/dashboards-analytics.js"></script>

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>

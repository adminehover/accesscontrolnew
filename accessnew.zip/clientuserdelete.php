<?php 
  session_start();
  include 'inc/config.php';
  if ($_SESSION['username'] == "") {
    echo "<script>window.location.assign('index.php');</script>";
  }
  $device_id = $_GET['device_id'];
  $sql = "DELETE FROM clients WHERE CLIENT_ID = '$device_id'";
  $query = mysqli_query($con, $sql);
  if ($query) {
    echo "<script>window.location.assign('device_list.php');</script";
  }else{
    echo "<script>window.location.assign('device_list.php');</script";
  }
?>
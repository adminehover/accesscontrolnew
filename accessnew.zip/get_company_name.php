<?php 
	session_start();
	if ($_SESSION['username'] == "") {
		echo "<script>window.location.assign('index.php');</script>";
	}
	include 'inc/config.php';
	$client_type_id = $_POST['client_type_id'];
	$sql = "SELECT * FROM company_name WHERE COMANY_TYPE_ID = '$client_type_id'";
	$query = mysqli_query($con, $sql);
?>
	<option value="">Please Select Company</option>
<?php
	while ($row = mysqli_fetch_assoc($query)) {
?>
	<option value="<?php echo $row['COMPANY_ID']; ?>"><?php echo $row['COMPANY_NAME']; ?></option>
<?php
	}
?>